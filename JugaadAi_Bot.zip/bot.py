
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "नमस्ते! मैं JugaadAi बोट हूँ। AI टूल्स का मजा लो और refer करके कमाओ!

Use /refer to get your link."
    )

async def refer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🔗 Apna Refer Link:
https://magiccorepower.com/?ref=ad7bf96919a3230bbd0c09285c9e226c0dcb8d56

🪙 1 refer = 10 points
Redeem @ 100 points = ₹10"
    )

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("refer", refer))

app.run_polling()
